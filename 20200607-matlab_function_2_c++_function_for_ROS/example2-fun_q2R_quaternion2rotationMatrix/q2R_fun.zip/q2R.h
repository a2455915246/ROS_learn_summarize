//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  q2R.h
//
//  Code generation for function 'q2R'
//


#ifndef Q2R_H
#define Q2R_H

// Include files
#include <cstddef>
#include <cstdlib>
#include "rtwtypes.h"
#include "q2R_types.h"

// Function Declarations
extern void q2R(const double q[4], double R[9]);

#endif

// End of code generation (q2R.h)
