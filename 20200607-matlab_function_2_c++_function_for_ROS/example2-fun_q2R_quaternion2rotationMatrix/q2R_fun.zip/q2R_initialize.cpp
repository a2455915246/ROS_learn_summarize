//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  q2R_initialize.cpp
//
//  Code generation for function 'q2R_initialize'
//


// Include files
#include "q2R_initialize.h"
#include "q2R.h"

// Function Definitions
void q2R_initialize()
{
}

// End of code generation (q2R_initialize.cpp)
