//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  foo_terminate.h
//
//  Code generation for function 'foo_terminate'
//


#ifndef FOO_TERMINATE_H
#define FOO_TERMINATE_H

// Include files
#include <cstddef>
#include <cstdlib>
#include "rtwtypes.h"
#include "foo_types.h"

// Function Declarations
extern void foo_terminate();

#endif

// End of code generation (foo_terminate.h)
