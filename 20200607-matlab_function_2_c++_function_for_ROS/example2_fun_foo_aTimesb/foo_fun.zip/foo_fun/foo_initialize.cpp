//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  foo_initialize.cpp
//
//  Code generation for function 'foo_initialize'
//


// Include files
#include "foo_initialize.h"
#include "foo.h"

// Function Definitions
void foo_initialize()
{
}

// End of code generation (foo_initialize.cpp)
