//
//  Academic License - for use in teaching, academic research, and meeting
//  course requirements at degree granting institutions only.  Not for
//  government, commercial, or other organizational use.
//
//  foo_terminate.cpp
//
//  Code generation for function 'foo_terminate'
//


// Include files
#include "foo_terminate.h"
#include "foo.h"

// Function Definitions
void foo_terminate()
{
  // (no terminate code required)
}

// End of code generation (foo_terminate.cpp)
